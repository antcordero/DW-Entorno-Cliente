Crea array vacío:
- 3 formas: 
> [!NOTE]
> - `let array1 = new Array();`
> - `let array2 = Array();`
> - `let array3 = [];`

Crea array con elementos:
- 3 formas: 
> [!NOTE]
> - `let array1 = new Array(2);`
> - `let array2 = new Array(3,4);`
> - `let array3 = new Array["Luis"];`

De la misma forma se puede hacer con corchetes y sus valores:
> [!NOTE]
> - `let array1 = [2]`
> - `let array2 = [1,3]`
> - `let arrat3 = ["Luis"]`

